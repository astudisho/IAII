import Tkinter as Tk
import ventana

def main():
	v = ventana.Ventana()
	Tk.mainloop()

if __name__ == '__main__':
	main()